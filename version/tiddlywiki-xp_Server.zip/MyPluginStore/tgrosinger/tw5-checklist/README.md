# tw5-checklist
Simple checklist widget for TiddlyWiki5

For more information about this [TiddlyWiki](http://tiddlywiki.com) plugin, please visit the homepage:

https://grosinger.net/tw5-checklist/

## License

This project is [MIT licensed](https://github.com/tgrosinger/tw5-checklist/blob/master/tiddlers/license.tid).

