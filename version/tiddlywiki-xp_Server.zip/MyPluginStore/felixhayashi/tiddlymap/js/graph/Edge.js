"use strict";Object.defineProperty(exports,"__esModule",{value:true});var _utils=require("$:/plugins/felixhayashi/tiddlymap/js/utils");var _utils2=_interopRequireDefault(_utils);function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t)){throw new TypeError("Cannot call a class as a function")}}/* @preserve TW-Guard */
/*\

title: $:/plugins/felixhayashi/tiddlymap/js/Edge
type: application/javascript
module-type: library

@preserve

\*/
/* @preserve TW-Guard */var Edge=function e(t,i,s,l){_classCallCheck(this,e);this.from=t;this.to=i;this.type=s;this.id=l||_utils2.default.genUUID()};exports.default=Edge;
//# sourceMappingURL=./maps/felixhayashi/tiddlymap/js/graph/Edge.js.map
