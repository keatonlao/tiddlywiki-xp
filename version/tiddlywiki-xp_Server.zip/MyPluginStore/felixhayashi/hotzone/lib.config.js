/*\

title: $:/plugins/felixhayashi/hotzone/config.js
type: application/javascript
module-type: library

@preserve

\*/
(function(){"use strict";exports.config={classNames:{storyRiver:"tc-story-river",tiddlerFrame:"tc-tiddler-frame",tiddlerTitle:"tc-title"},references:{userConfig:"$:/config/hotzone/focusOffset",focussedTiddlerStore:"$:/temp/focussedTiddler"},checkbackTime:$tw.utils.getAnimationDuration()}})();