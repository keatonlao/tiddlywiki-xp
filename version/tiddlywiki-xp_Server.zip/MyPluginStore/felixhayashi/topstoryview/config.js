/*\

title: $:/plugins/felixhayashi/topstoryview/config.js
type: application/javascript
module-type: library

@preserve

\*/
(function(){"use strict";exports.config={classNames:{storyRiver:"tc-story-river",backDrop:"story-backdrop",tiddlerFrame:"tc-tiddler-frame",tiddlerTitle:"tc-title"},references:{userConfig:"$:/config/topStoryView",focussedTiddlerStore:"$:/temp/focussedTiddler",refreshTrigger:"$:/temp/focussedTiddler/refresh"},checkbackTime:$tw.utils.getAnimationDuration()}})();